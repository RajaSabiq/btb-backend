const mysql = require('mysql2');
const connection = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  // user: 'kingcobblertest_btb_card',
  // password: 'My0nqYIlW^0b',
  // database: 'kingcobblertest_btb_card',
  user: 'root',
  password: '',
  database: 'btn_card',
});

module.exports = connection;
